import Login from "./login";

export default function Register() {
  return <Login />;
}